# jquery.slidey
A simple (!) image rotator built with jquery

A demo can be tested at <https://tpaksu.github.io/jquery.slidey>